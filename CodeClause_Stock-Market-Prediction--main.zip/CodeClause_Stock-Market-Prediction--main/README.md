# CodeClause_Stock-Market-Prediction-
Stock Market Prediction Using Linear Regression

For most stock investors, the favorite question is "How long should 
we hold a stock for?" Every investor wants to know how not to act too fearful 
and too greedy. And not all of them have Warren Buffet to guide them at every 
stem. We'd suggest that you stop looking for him. Rather, build your stock 
market predictor With artificial intelligence tools like Machine Learning. And the 
approach to this is so simple that you can consider adding this to your Data 
Science Projects list. 
